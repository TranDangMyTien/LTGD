﻿
namespace BTH5
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btPlay = new System.Windows.Forms.Button();
            this.btInit = new System.Windows.Forms.Button();
            this.tbSoNT = new System.Windows.Forms.TextBox();
            this.tbTBC = new System.Windows.Forms.TextBox();
            this.tbSumLe = new System.Windows.Forms.TextBox();
            this.tbSumChan = new System.Windows.Forms.TextBox();
            this.tbMang = new System.Windows.Forms.TextBox();
            this.tbSoPt = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btPlay
            // 
            this.btPlay.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btPlay.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btPlay.Location = new System.Drawing.Point(664, 46);
            this.btPlay.Name = "btPlay";
            this.btPlay.Size = new System.Drawing.Size(279, 61);
            this.btPlay.TabIndex = 15;
            this.btPlay.Text = "Thống kê";
            this.btPlay.UseVisualStyleBackColor = false;
            this.btPlay.Click += new System.EventHandler(this.btPlay_Click);
            // 
            // btInit
            // 
            this.btInit.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btInit.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btInit.Location = new System.Drawing.Point(348, 44);
            this.btInit.Name = "btInit";
            this.btInit.Size = new System.Drawing.Size(279, 61);
            this.btInit.TabIndex = 16;
            this.btInit.Text = "Tạo mảng ngẫu nhiên";
            this.btInit.UseVisualStyleBackColor = false;
            this.btInit.Click += new System.EventHandler(this.btInit_Click);
            // 
            // tbSoNT
            // 
            this.tbSoNT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSoNT.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tbSoNT.Location = new System.Drawing.Point(320, 463);
            this.tbSoNT.Name = "tbSoNT";
            this.tbSoNT.Size = new System.Drawing.Size(103, 39);
            this.tbSoNT.TabIndex = 9;
            this.tbSoNT.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTBC
            // 
            this.tbTBC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbTBC.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tbTBC.Location = new System.Drawing.Point(320, 392);
            this.tbTBC.Name = "tbTBC";
            this.tbTBC.Size = new System.Drawing.Size(103, 39);
            this.tbTBC.TabIndex = 10;
            this.tbTBC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbSumLe
            // 
            this.tbSumLe.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSumLe.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tbSumLe.Location = new System.Drawing.Point(320, 321);
            this.tbSumLe.Name = "tbSumLe";
            this.tbSumLe.Size = new System.Drawing.Size(103, 39);
            this.tbSumLe.TabIndex = 11;
            this.tbSumLe.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbSumChan
            // 
            this.tbSumChan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSumChan.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tbSumChan.Location = new System.Drawing.Point(320, 250);
            this.tbSumChan.Name = "tbSumChan";
            this.tbSumChan.Size = new System.Drawing.Size(103, 39);
            this.tbSumChan.TabIndex = 12;
            this.tbSumChan.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbMang
            // 
            this.tbMang.BackColor = System.Drawing.SystemColors.Info;
            this.tbMang.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbMang.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tbMang.Location = new System.Drawing.Point(320, 179);
            this.tbMang.Name = "tbMang";
            this.tbMang.Size = new System.Drawing.Size(623, 39);
            this.tbMang.TabIndex = 13;
            // 
            // tbSoPt
            // 
            this.tbSoPt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSoPt.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tbSoPt.Location = new System.Drawing.Point(205, 58);
            this.tbSoPt.Name = "tbSoPt";
            this.tbSoPt.Size = new System.Drawing.Size(105, 39);
            this.tbSoPt.TabIndex = 14;
            this.tbSoPt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(11, 473);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(235, 32);
            this.label6.TabIndex = 3;
            this.label6.Text = "Số các số nguyên tố:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(11, 254);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(222, 32);
            this.label3.TabIndex = 4;
            this.label3.Text = "Tổng phần tử chẵn:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(11, 400);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(195, 32);
            this.label5.TabIndex = 5;
            this.label5.Text = "Trung bình cộng:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(11, 327);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(190, 32);
            this.label4.TabIndex = 6;
            this.label4.Text = "Tổng phần tử lẻ:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(11, 181);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(175, 32);
            this.label2.TabIndex = 7;
            this.label2.Text = "Mảng ban đầu:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(26, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 32);
            this.label1.TabIndex = 8;
            this.label1.Text = "Số phần tử:";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1023, 590);
            this.Controls.Add(this.btPlay);
            this.Controls.Add(this.btInit);
            this.Controls.Add(this.tbSoNT);
            this.Controls.Add(this.tbTBC);
            this.Controls.Add(this.tbSumLe);
            this.Controls.Add(this.tbSumChan);
            this.Controls.Add(this.tbMang);
            this.Controls.Add(this.tbSoPt);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btPlay;
        private System.Windows.Forms.Button btInit;
        private System.Windows.Forms.TextBox tbSoNT;
        private System.Windows.Forms.TextBox tbTBC;
        private System.Windows.Forms.TextBox tbSumLe;
        private System.Windows.Forms.TextBox tbSumChan;
        private System.Windows.Forms.TextBox tbMang;
        private System.Windows.Forms.TextBox tbSoPt;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}