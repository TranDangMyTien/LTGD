﻿
namespace BTH5
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbName = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtS1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtS2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtS3 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btChen = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.tbVitriChen = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btLay = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.tbKituLay = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbVitriLay = new System.Windows.Forms.TextBox();
            this.btThaythe = new System.Windows.Forms.Button();
            this.btDaotu = new System.Windows.Forms.Button();
            this.btXoa = new System.Windows.Forms.Button();
            this.btChuanhoa = new System.Windows.Forms.Button();
            this.btKhoiphuc = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbName
            // 
            this.lbName.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbName.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbName.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbName.Location = new System.Drawing.Point(0, 0);
            this.lbName.Name = "lbName";
            this.lbName.Size = new System.Drawing.Size(1066, 84);
            this.lbName.TabIndex = 0;
            this.lbName.Text = "label1";
            this.lbName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(40, 128);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 32);
            this.label2.TabIndex = 1;
            this.label2.Text = "Chuỗi 1:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtS1
            // 
            this.txtS1.BackColor = System.Drawing.SystemColors.Info;
            this.txtS1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtS1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtS1.Location = new System.Drawing.Point(139, 125);
            this.txtS1.Name = "txtS1";
            this.txtS1.Size = new System.Drawing.Size(899, 39);
            this.txtS1.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(40, 180);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 32);
            this.label3.TabIndex = 1;
            this.label3.Text = "Chuỗi 2:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtS2
            // 
            this.txtS2.BackColor = System.Drawing.SystemColors.Window;
            this.txtS2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtS2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtS2.Location = new System.Drawing.Point(139, 177);
            this.txtS2.Name = "txtS2";
            this.txtS2.Size = new System.Drawing.Size(450, 39);
            this.txtS2.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(595, 181);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 32);
            this.label4.TabIndex = 1;
            this.label4.Text = "Chuỗi 3:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtS3
            // 
            this.txtS3.BackColor = System.Drawing.SystemColors.Window;
            this.txtS3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtS3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtS3.Location = new System.Drawing.Point(694, 178);
            this.txtS3.Name = "txtS3";
            this.txtS3.Size = new System.Drawing.Size(344, 39);
            this.txtS3.TabIndex = 2;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btChen);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.tbVitriChen);
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupBox1.Location = new System.Drawing.Point(40, 259);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(300, 150);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Chèn chữ s2 vào s1";
            // 
            // btChen
            // 
            this.btChen.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btChen.Location = new System.Drawing.Point(200, 77);
            this.btChen.Name = "btChen";
            this.btChen.Size = new System.Drawing.Size(94, 48);
            this.btChen.TabIndex = 3;
            this.btChen.Text = "Chèn";
            this.btChen.UseVisualStyleBackColor = false;
            this.btChen.Click += new System.EventHandler(this.btChen_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(6, 85);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 32);
            this.label5.TabIndex = 1;
            this.label5.Text = "Vị trí:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbVitriChen
            // 
            this.tbVitriChen.BackColor = System.Drawing.SystemColors.Window;
            this.tbVitriChen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbVitriChen.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tbVitriChen.Location = new System.Drawing.Point(81, 83);
            this.tbVitriChen.Name = "tbVitriChen";
            this.tbVitriChen.Size = new System.Drawing.Size(97, 39);
            this.tbVitriChen.TabIndex = 2;
            this.tbVitriChen.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btLay);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.tbKituLay);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.tbVitriLay);
            this.groupBox2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupBox2.Location = new System.Drawing.Point(40, 443);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(680, 150);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Lấy chuỗi con trong s1";
            // 
            // btLay
            // 
            this.btLay.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btLay.Location = new System.Drawing.Point(496, 77);
            this.btLay.Name = "btLay";
            this.btLay.Size = new System.Drawing.Size(180, 48);
            this.btLay.TabIndex = 3;
            this.btLay.Text = "Lấy chuỗi con";
            this.btLay.UseVisualStyleBackColor = false;
            this.btLay.Click += new System.EventHandler(this.btLay_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(260, 85);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 32);
            this.label7.TabIndex = 1;
            this.label7.Text = "Số kí tự:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbKituLay
            // 
            this.tbKituLay.BackColor = System.Drawing.SystemColors.Window;
            this.tbKituLay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbKituLay.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tbKituLay.Location = new System.Drawing.Point(366, 83);
            this.tbKituLay.Name = "tbKituLay";
            this.tbKituLay.Size = new System.Drawing.Size(97, 39);
            this.tbKituLay.TabIndex = 2;
            this.tbKituLay.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(6, 85);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 32);
            this.label6.TabIndex = 1;
            this.label6.Text = "Từ vị trí:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbVitriLay
            // 
            this.tbVitriLay.BackColor = System.Drawing.SystemColors.Window;
            this.tbVitriLay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbVitriLay.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tbVitriLay.Location = new System.Drawing.Point(112, 83);
            this.tbVitriLay.Name = "tbVitriLay";
            this.tbVitriLay.Size = new System.Drawing.Size(97, 39);
            this.tbVitriLay.TabIndex = 2;
            this.tbVitriLay.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btThaythe
            // 
            this.btThaythe.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btThaythe.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btThaythe.Location = new System.Drawing.Point(604, 278);
            this.btThaythe.Name = "btThaythe";
            this.btThaythe.Size = new System.Drawing.Size(206, 48);
            this.btThaythe.TabIndex = 3;
            this.btThaythe.Text = "Thay thế s2 = s3";
            this.btThaythe.UseVisualStyleBackColor = false;
            this.btThaythe.Click += new System.EventHandler(this.btThaythe_Click);
            // 
            // btDaotu
            // 
            this.btDaotu.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btDaotu.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btDaotu.Location = new System.Drawing.Point(820, 278);
            this.btDaotu.Name = "btDaotu";
            this.btDaotu.Size = new System.Drawing.Size(218, 48);
            this.btDaotu.TabIndex = 3;
            this.btDaotu.Text = "Đảo từ trong s1";
            this.btDaotu.UseVisualStyleBackColor = false;
            this.btDaotu.Click += new System.EventHandler(this.btDaotu_Click);
            // 
            // btXoa
            // 
            this.btXoa.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btXoa.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btXoa.Location = new System.Drawing.Point(604, 361);
            this.btXoa.Name = "btXoa";
            this.btXoa.Size = new System.Drawing.Size(206, 48);
            this.btXoa.TabIndex = 3;
            this.btXoa.Text = "Xóa s2 trong s1";
            this.btXoa.UseVisualStyleBackColor = false;
            this.btXoa.Click += new System.EventHandler(this.btXoa_Click);
            // 
            // btChuanhoa
            // 
            this.btChuanhoa.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btChuanhoa.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btChuanhoa.Location = new System.Drawing.Point(820, 361);
            this.btChuanhoa.Name = "btChuanhoa";
            this.btChuanhoa.Size = new System.Drawing.Size(218, 48);
            this.btChuanhoa.TabIndex = 3;
            this.btChuanhoa.Text = "Chuẩn hóa chuỗi";
            this.btChuanhoa.UseVisualStyleBackColor = false;
            this.btChuanhoa.Click += new System.EventHandler(this.btChuanhoa_Click);
            // 
            // btKhoiphuc
            // 
            this.btKhoiphuc.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btKhoiphuc.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btKhoiphuc.Location = new System.Drawing.Point(807, 512);
            this.btKhoiphuc.Name = "btKhoiphuc";
            this.btKhoiphuc.Size = new System.Drawing.Size(180, 48);
            this.btKhoiphuc.TabIndex = 3;
            this.btKhoiphuc.Text = "Khôi phục";
            this.btKhoiphuc.UseVisualStyleBackColor = false;
            this.btKhoiphuc.Click += new System.EventHandler(this.btKhoiphuc_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 150;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1066, 673);
            this.Controls.Add(this.btChuanhoa);
            this.Controls.Add(this.btDaotu);
            this.Controls.Add(this.btKhoiphuc);
            this.Controls.Add(this.btXoa);
            this.Controls.Add(this.btThaythe);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txtS3);
            this.Controls.Add(this.txtS2);
            this.Controls.Add(this.txtS1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbName);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Vị trí:";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtS1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtS2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtS3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btChen;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbVitriChen;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btLay;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbKituLay;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbVitriLay;
        private System.Windows.Forms.Button btThaythe;
        private System.Windows.Forms.Button btDaotu;
        private System.Windows.Forms.Button btXoa;
        private System.Windows.Forms.Button btChuanhoa;
        private System.Windows.Forms.Button btKhoiphuc;
        private System.Windows.Forms.Timer timer1;
    }
}

