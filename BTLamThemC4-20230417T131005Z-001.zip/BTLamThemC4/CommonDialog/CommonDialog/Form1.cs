﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;
using System.Threading;


namespace CommonDialog
{
    public partial class Form1 : Form
    {
        private bool aOpen;
        private bool aClose;
        public Form1()
        {
            this.Opacity = 0;
            InitializeComponent();
        }

        private void btnMTT_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                listKetQua.Items.Add(dlg.FileName);

            }
        }

        private void btnNTT_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            dlg.Multiselect = true;
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                foreach (string file in dlg.FileNames)
                {
                    listKetQua.Items.Add(file);
                }
            }
        }

        private void btnThuMuc_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog f = new FolderBrowserDialog();
            f.ShowDialog();
            listKetQua.Items.Add(f.SelectedPath);
        }

        private void btnNen_Click(object sender, EventArgs e)
        {
            ColorDialog f = new ColorDialog();
            f.ShowDialog();
            listKetQua.BackColor = f.Color;
        }

        private void btnChu_Click(object sender, EventArgs e)
        {
            ColorDialog f = new ColorDialog();
            f.ShowDialog();
            listKetQua.ForeColor = f.Color;
        }

        private void btnFont_Click(object sender, EventArgs e)
        {
            FontDialog f = new FontDialog();
            f.ShowDialog();
            listKetQua.Font = f.Font;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            listKetQua.Items.Clear();
            listKetQua.BackColor = Color.Bisque;
            listKetQua.ForeColor = Color.Black;
        }
        private void timeOut_Tick(object sender, EventArgs e)
        {
            this.Opacity -= 0.05;
            if (this.Opacity <= 0)
            {
                Application.Exit();
                aClose = true;
            }
        }
        private void btnThoat_Click(object sender, EventArgs e)
        {
            if (!aClose)
            {
                timerOut.Enabled = true;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timerLoad.Enabled = true;
            aClose = false;
        }

        private void timerLoad_Tick(object sender, EventArgs e)
        {
            if (!aOpen)
            {
                this.Opacity += 0.05;
                if (this.Opacity >= 1)
                {
                    aOpen = true;
                }
            }
        }

        private void timerOut_Tick(object sender, EventArgs e)
        {
            this.Opacity -= 0.05;
            if (this.Opacity <= 0)
            {
                Application.Exit();
                aClose = true;
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!aClose)
            {
                e.Cancel = true;
                timerOut.Enabled = true;
            }
        }
    }
}
