﻿
namespace Calculator
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btDel = new System.Windows.Forms.Button();
            this.btR = new System.Windows.Forms.Button();
            this.bt7 = new System.Windows.Forms.Button();
            this.bt8 = new System.Windows.Forms.Button();
            this.bt9 = new System.Windows.Forms.Button();
            this.btChia = new System.Windows.Forms.Button();
            this.bt4 = new System.Windows.Forms.Button();
            this.bt5 = new System.Windows.Forms.Button();
            this.bt6 = new System.Windows.Forms.Button();
            this.btNhan = new System.Windows.Forms.Button();
            this.bt1 = new System.Windows.Forms.Button();
            this.bt2 = new System.Windows.Forms.Button();
            this.bt3 = new System.Windows.Forms.Button();
            this.btTru = new System.Windows.Forms.Button();
            this.bt0 = new System.Windows.Forms.Button();
            this.btBang = new System.Windows.Forms.Button();
            this.btCong = new System.Windows.Forms.Button();
            this.lbTinh = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(537, 112);
            this.label1.TabIndex = 0;
            this.label1.Text = "Calculator";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btDel
            // 
            this.btDel.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btDel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btDel.Location = new System.Drawing.Point(116, 250);
            this.btDel.Name = "btDel";
            this.btDel.Size = new System.Drawing.Size(128, 48);
            this.btDel.TabIndex = 2;
            this.btDel.Text = "DEL";
            this.btDel.UseVisualStyleBackColor = true;
            this.btDel.Click += new System.EventHandler(this.btDel_Click);
            // 
            // btR
            // 
            this.btR.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btR.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btR.Location = new System.Drawing.Point(303, 250);
            this.btR.Name = "btR";
            this.btR.Size = new System.Drawing.Size(128, 48);
            this.btR.TabIndex = 2;
            this.btR.Text = "R";
            this.btR.UseVisualStyleBackColor = true;
            this.btR.Click += new System.EventHandler(this.btR_Click);
            // 
            // bt7
            // 
            this.bt7.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bt7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.bt7.Location = new System.Drawing.Point(75, 331);
            this.bt7.Name = "bt7";
            this.bt7.Size = new System.Drawing.Size(89, 48);
            this.bt7.TabIndex = 3;
            this.bt7.Text = "7";
            this.bt7.UseVisualStyleBackColor = true;
            this.bt7.Click += new System.EventHandler(this.bt0_Click);
            // 
            // bt8
            // 
            this.bt8.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bt8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.bt8.Location = new System.Drawing.Point(170, 331);
            this.bt8.Name = "bt8";
            this.bt8.Size = new System.Drawing.Size(87, 48);
            this.bt8.TabIndex = 3;
            this.bt8.Text = "8";
            this.bt8.UseVisualStyleBackColor = true;
            this.bt8.Click += new System.EventHandler(this.bt0_Click);
            // 
            // bt9
            // 
            this.bt9.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bt9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.bt9.Location = new System.Drawing.Point(263, 331);
            this.bt9.Name = "bt9";
            this.bt9.Size = new System.Drawing.Size(84, 48);
            this.bt9.TabIndex = 3;
            this.bt9.Text = "9";
            this.bt9.UseVisualStyleBackColor = true;
            this.bt9.Click += new System.EventHandler(this.bt0_Click);
            // 
            // btChia
            // 
            this.btChia.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btChia.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btChia.Location = new System.Drawing.Point(366, 331);
            this.btChia.Name = "btChia";
            this.btChia.Size = new System.Drawing.Size(95, 48);
            this.btChia.TabIndex = 3;
            this.btChia.Text = "/";
            this.btChia.UseVisualStyleBackColor = true;
            this.btChia.Click += new System.EventHandler(this.Operation_Click);
            // 
            // bt4
            // 
            this.bt4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bt4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.bt4.Location = new System.Drawing.Point(75, 403);
            this.bt4.Name = "bt4";
            this.bt4.Size = new System.Drawing.Size(89, 48);
            this.bt4.TabIndex = 3;
            this.bt4.Text = "4";
            this.bt4.UseVisualStyleBackColor = true;
            this.bt4.Click += new System.EventHandler(this.bt0_Click);
            // 
            // bt5
            // 
            this.bt5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bt5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.bt5.Location = new System.Drawing.Point(170, 403);
            this.bt5.Name = "bt5";
            this.bt5.Size = new System.Drawing.Size(87, 48);
            this.bt5.TabIndex = 3;
            this.bt5.Text = "5";
            this.bt5.UseVisualStyleBackColor = true;
            this.bt5.Click += new System.EventHandler(this.bt0_Click);
            // 
            // bt6
            // 
            this.bt6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bt6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.bt6.Location = new System.Drawing.Point(263, 403);
            this.bt6.Name = "bt6";
            this.bt6.Size = new System.Drawing.Size(84, 48);
            this.bt6.TabIndex = 3;
            this.bt6.Text = "6";
            this.bt6.UseVisualStyleBackColor = true;
            this.bt6.Click += new System.EventHandler(this.bt0_Click);
            // 
            // btNhan
            // 
            this.btNhan.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btNhan.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btNhan.Location = new System.Drawing.Point(366, 403);
            this.btNhan.Name = "btNhan";
            this.btNhan.Size = new System.Drawing.Size(95, 48);
            this.btNhan.TabIndex = 3;
            this.btNhan.Text = "x";
            this.btNhan.UseVisualStyleBackColor = true;
            this.btNhan.Click += new System.EventHandler(this.Operation_Click);
            // 
            // bt1
            // 
            this.bt1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bt1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.bt1.Location = new System.Drawing.Point(75, 475);
            this.bt1.Name = "bt1";
            this.bt1.Size = new System.Drawing.Size(89, 48);
            this.bt1.TabIndex = 3;
            this.bt1.Text = "1";
            this.bt1.UseVisualStyleBackColor = true;
            this.bt1.Click += new System.EventHandler(this.bt0_Click);
            // 
            // bt2
            // 
            this.bt2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bt2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.bt2.Location = new System.Drawing.Point(170, 475);
            this.bt2.Name = "bt2";
            this.bt2.Size = new System.Drawing.Size(87, 48);
            this.bt2.TabIndex = 3;
            this.bt2.Text = "2";
            this.bt2.UseVisualStyleBackColor = true;
            this.bt2.Click += new System.EventHandler(this.bt0_Click);
            // 
            // bt3
            // 
            this.bt3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bt3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.bt3.Location = new System.Drawing.Point(263, 475);
            this.bt3.Name = "bt3";
            this.bt3.Size = new System.Drawing.Size(84, 48);
            this.bt3.TabIndex = 3;
            this.bt3.Text = "3";
            this.bt3.UseVisualStyleBackColor = true;
            this.bt3.Click += new System.EventHandler(this.bt0_Click);
            // 
            // btTru
            // 
            this.btTru.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btTru.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btTru.Location = new System.Drawing.Point(366, 475);
            this.btTru.Name = "btTru";
            this.btTru.Size = new System.Drawing.Size(95, 48);
            this.btTru.TabIndex = 3;
            this.btTru.Text = "-";
            this.btTru.UseVisualStyleBackColor = true;
            this.btTru.Click += new System.EventHandler(this.Operation_Click);
            // 
            // bt0
            // 
            this.bt0.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bt0.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.bt0.Location = new System.Drawing.Point(75, 541);
            this.bt0.Name = "bt0";
            this.bt0.Size = new System.Drawing.Size(89, 48);
            this.bt0.TabIndex = 4;
            this.bt0.Text = "0";
            this.bt0.UseVisualStyleBackColor = true;
            this.bt0.Click += new System.EventHandler(this.bt0_Click);
            // 
            // btBang
            // 
            this.btBang.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btBang.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btBang.Location = new System.Drawing.Point(170, 541);
            this.btBang.Name = "btBang";
            this.btBang.Size = new System.Drawing.Size(177, 48);
            this.btBang.TabIndex = 4;
            this.btBang.Text = "=";
            this.btBang.UseVisualStyleBackColor = true;
            this.btBang.Click += new System.EventHandler(this.btBang_Click);
            // 
            // btCong
            // 
            this.btCong.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btCong.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btCong.Location = new System.Drawing.Point(366, 541);
            this.btCong.Name = "btCong";
            this.btCong.Size = new System.Drawing.Size(94, 48);
            this.btCong.TabIndex = 4;
            this.btCong.Text = "+";
            this.btCong.UseVisualStyleBackColor = true;
            this.btCong.Click += new System.EventHandler(this.Operation_Click);
            // 
            // lbTinh
            // 
            this.lbTinh.BackColor = System.Drawing.Color.White;
            this.lbTinh.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTinh.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbTinh.Location = new System.Drawing.Point(12, 112);
            this.lbTinh.Name = "lbTinh";
            this.lbTinh.Size = new System.Drawing.Size(513, 108);
            this.lbTinh.TabIndex = 5;
            this.lbTinh.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(537, 633);
            this.Controls.Add(this.lbTinh);
            this.Controls.Add(this.btBang);
            this.Controls.Add(this.btCong);
            this.Controls.Add(this.bt0);
            this.Controls.Add(this.btTru);
            this.Controls.Add(this.bt3);
            this.Controls.Add(this.btNhan);
            this.Controls.Add(this.bt6);
            this.Controls.Add(this.bt2);
            this.Controls.Add(this.btChia);
            this.Controls.Add(this.bt5);
            this.Controls.Add(this.bt1);
            this.Controls.Add(this.bt9);
            this.Controls.Add(this.bt4);
            this.Controls.Add(this.bt8);
            this.Controls.Add(this.bt7);
            this.Controls.Add(this.btR);
            this.Controls.Add(this.btDel);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Simple Calculator ";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btDel;
        private System.Windows.Forms.Button btR;
        private System.Windows.Forms.Button bt7;
        private System.Windows.Forms.Button bt8;
        private System.Windows.Forms.Button bt9;
        private System.Windows.Forms.Button btChia;
        private System.Windows.Forms.Button bt4;
        private System.Windows.Forms.Button bt5;
        private System.Windows.Forms.Button bt6;
        private System.Windows.Forms.Button btNhan;
        private System.Windows.Forms.Button bt1;
        private System.Windows.Forms.Button bt2;
        private System.Windows.Forms.Button bt3;
        private System.Windows.Forms.Button btTru;
        private System.Windows.Forms.Button bt0;
        private System.Windows.Forms.Button btBang;
        private System.Windows.Forms.Button btCong;
        private System.Windows.Forms.Label lbTinh;
    }
}

